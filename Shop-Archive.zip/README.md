step 1 run: npm install --global yarn
step 2 run: yarn install
step 3 run: npm start
