export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyCXVTjTuBUXf-UWlpKfKHjomfPezutmPwI',
    authDomain: 'cas-fee-shop.firebaseapp.com',
    databaseURL: 'https://cas-fee-shop.firebaseio.com',
    projectId: 'cas-fee-shop',
    storageBucket: 'cas-fee-shop.appspot.com',
    messagingSenderId: '323643286137'
  }
};
